import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */
interface UserInfo{
	boolean getUsername(String firstName,String lastName);
	boolean getPhoneNumber(int phoneNumber);
	boolean getEmployeeId(String employeeId);
	boolean getAddress(String[] address);
}

interface HousingLoan{
	int MIN_ACCOUNT_BALANCE_HOUSING=1000000;
	int TIME_PERIOD_HOUSING=5;
	void offerHousingLoan(User user);
}

interface EducationLoan{
	int MIN_ACCOUNT_BALANCE_EDUCATION=1000000;
	int TIME_PERIOD_EDUCATION=5;
	void offerEducationLoan(User user);
}

interface TravelLoan{
	int MIN_ACCOUNT_BALANCE_TRAVEL=1000000;
	int TIME_PERIOD_TRAVEL=5;
	void offerTravelLoan(User user);
}

interface PersonalLoan{
	int MIN_ACCOUNT_BALANCE_PERSONAL=0;
	int TIME_PERIOD_PERSONAL=5;
	void offerPersonalLoan(User user);
}

class User{
	String firstName;
	String lastName;
	int phoneNumber;
	String employeeId;
	String[] address;
	int parentAccountMoney;
	int accountMoney;
	
	User(String firstName,String lastName,int phoneNumber,String employeeId,String[] address,int parentAccountMoney,int accountMoney){
		this.firstName=firstName;
		this.lastName=lastName;
		this.phoneNumber=phoneNumber;
		this.employeeId=employeeId;
		this.address=address;
		this.parentAccountMoney=parentAccountMoney;
		this.accountMoney=accountMoney;
	}
}


public class Bank implements UserInfo,HousingLoan,EducationLoan,TravelLoan,PersonalLoan{

	/**
	 * @param args
	 */
	
	public boolean getUsername(String firstName,String lastName){
		if(firstName.length()>16||lastName.length()>16){
			return false;
		}
		return true;
	}
	
	public boolean getPhoneNumber(int phoneNumber,int length){
		String number=""+phoneNumber;
		if(number.length()!=length){
			return false;
		}
		return true;
	}
	
	public boolean getEmployeeId(String employeeId){
		try 
        {  
            Integer.parseInt(employeeId);
            return true;
        }  
        catch (NumberFormatException e)  
        { 
            return false; 
        } 
	}
	
	public boolean getAddress(String[] address){
		for(String str:address){
			if(str.isEmpty()){
				return false;
			}
		}
		return true;
	}
	
	@Override
	public boolean getPhoneNumber(int phoneNumber) {
		// TODO Auto-generated method stub
		return false;
	}
	
	public boolean validUser(String firstName,String lastName,int phoneNumber,String employeeId,String[] address,int parentAccountMoney,int accountMoney){
		if(getUsername(firstName,lastName)&&getPhoneNumber(phoneNumber,10)&&getEmployeeId(employeeId)&&getAddress(address)){
			return true;
		}else{
			return false;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner obj=new Scanner(System.in);
		Bank bank=new Bank();
		User user1 = null;
		System.out.println("Enter the first name of user");
		String firstName=obj.next();
		
		System.out.println("Enter the last name of user");
		String lastName=obj.next();
		
		System.out.println("Enter the phone number of employee(10 digit)");
		int phoneNumber=obj.nextInt();
		
		System.out.println("Enter the employeeId");
		String empId=obj.next();
		
		System.out.println("Enter the house number");
		String houseNumber=obj.next();
		
		System.out.println("Enter the block name");
		String blockName=obj.next();
		
		String[] address={houseNumber,blockName};
		
		System.out.println("Enter the amount in account of user");
		int accountMoney=obj.nextInt();
		
		System.out.println("Do the parents have account in bank? yes/no only");
		String resp=obj.next();
		int parentAccountMoney=0;
		if(resp.equals("yes")){
			System.out.println("Enter the amount in parents account");
			parentAccountMoney=obj.nextInt();
		}
		
		boolean valid=bank.validUser(firstName,lastName,phoneNumber,empId,address,parentAccountMoney,accountMoney);
		if(!valid){
			System.out.println("Invalid details");
			obj.close();
			return;
		}
		System.out.println("Valid details");
		user1=new User(firstName,lastName,phoneNumber,empId,address,parentAccountMoney,accountMoney);
		
		while(true){
			System.out.println("Enter 1/2/3/4/5 as your choice:-");
			System.out.println("1. Get housing loan");
			System.out.println("2. Get education loan");
			System.out.println("3. Get personal loan");
			System.out.println("4. Get travel loan");
			System.out.println("5. Exit");
			int option=obj.nextInt();
			if(option==1){
				bank.offerHousingLoan(user1);
			}else if(option==2){
				bank.offerEducationLoan(user1);
			}else if(option==3){
				bank.offerPersonalLoan(user1);
			}else if(option==4){
				bank.offerTravelLoan(user1);
			}else if(option==5){
				obj.close();
				return;
			}else{
				System.out.println("Invalid option. Please write 1/2/3/4/5 as input");
			}
		}
		
	}

	@Override
	public void offerPersonalLoan(User user) {
		// TODO Auto-generated method stub
		System.out.println("User elgible for personal loan");
		System.out.println("Needs to payback in 1year with 1% simple interest");
	}

	@Override
	public void offerTravelLoan(User user) {
		// TODO Auto-generated method stub
		int accountMoney=user.accountMoney;
		if(accountMoney<MIN_ACCOUNT_BALANCE_TRAVEL){
			System.out.println("Travel Loan cannot be offered due to insufficient balance");
		}else{
			System.out.println("Travel Loan can be offered");
		}
	}

	@Override
	public void offerEducationLoan(User user) {
		// TODO Auto-generated method stub
		int parentAccountMoney=user.parentAccountMoney;
		if(parentAccountMoney<MIN_ACCOUNT_BALANCE_EDUCATION){
			System.out.println("Education Loan cannot be offered due to insufficient balance");
		}else{
			System.out.println("Education Loan can be offered");
		}
	}

	@Override
	public void offerHousingLoan(User user) {
		// TODO Auto-generated method stub
		int accountMoney=user.accountMoney;
		if(accountMoney<MIN_ACCOUNT_BALANCE_HOUSING){
			System.out.println("Housing Loan cannot be offered due to insufficient balance");
		}else{
			System.out.println("Housing Loan can be offered");
		}
	}

	

}
