import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class Main{
	void run(){
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		HashMap<String,String> map=new HashMap<String,String>();
		for(int i=0;i<n;i++){
			String key=scanner.next();
			String name=scanner.next();
			map.put(key,name);
		}
		ArrayList<String> names=UserMainCode.getName(map);
		for(String name:names){
			System.out.println(name);
		}
	}
}

class UserMainCode{
	static ArrayList<String> getName(HashMap<String,String> map){
		ArrayList<String> list=new ArrayList<String>();
		for(String empId:map.keySet()){
			String name=map.get(empId);
			char first=name.charAt(0);
			if(!Character.isLowerCase(first)){
				continue;
			}
			char last=name.charAt(name.length()-1);
			if(!Character.isUpperCase(last)){
				continue;
			}
			boolean hasDigit = name.matches(".*\\d+.*");
			if(hasDigit){
				list.add(name);
			}
		}
		return list;
	}
}

public class QuestionTwentyTwoTransfer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
