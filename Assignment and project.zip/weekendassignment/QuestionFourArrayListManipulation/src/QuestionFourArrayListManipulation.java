import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class UserMainCode{
	static List<Integer> generateOddEvenList(List<Integer> list1,List<Integer> list2,int n){
		List<Integer> list3=new ArrayList<Integer>();
		for(int i=0;i<n;i++){
			if(i%2==0){
				list3.add(list2.get(i));
			}else{
				list3.add(list1.get(i));
			}
		}
		return list3;
	}
}

class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		int n=obj.nextInt();
		List<Integer> list1=new ArrayList<Integer>();
		List<Integer> list2=new ArrayList<Integer>();
		for(int i=0;i<n;i++){
			list1.add(obj.nextInt());
		}
		for(int i=n;i<2*n;i++){
			list2.add(obj.nextInt());
		}
		List<Integer> list3=UserMainCode.generateOddEvenList(list1, list2, n);
		for(int i=0;i<n;i++){
			System.out.println(list3.get(i)+" ");
		}
	}
}

public class QuestionFourArrayListManipulation {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
