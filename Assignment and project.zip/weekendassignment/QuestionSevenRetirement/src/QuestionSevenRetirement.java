import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		int n=obj.nextInt();
		HashMap<String,String> map=new HashMap<String,String>();
		for(int i=0;i<n;i++){
			String key=obj.next();
			String date=obj.next();
			map.put(key, date);
		}
		ArrayList<String> list=UserMainCode.retirementEmployeeList(map);
		for(String s:list){
			System.out.println(s);
		}
	}
}

class UserMainCode{
	static ArrayList<String> retirementEmployeeList(HashMap<String,String> map){
		ArrayList<String> list=new ArrayList<String>();
		for (String key:map.keySet()){
			String[] date=map.get(key).split("/");
			LocalDate birthdate = LocalDate.of(Integer.parseInt(date[2]),Integer.parseInt(date[1]), Integer.parseInt(date[0]));
			LocalDate now = LocalDate.of(2019,8,4);
			long years = ChronoUnit.YEARS.between(birthdate, now);
			if(years>=60){
				list.add(key);
			}
		}
		return list;
	}
}

public class QuestionSevenRetirement {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
