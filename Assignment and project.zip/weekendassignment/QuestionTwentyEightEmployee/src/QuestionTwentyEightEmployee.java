import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */
class Employee implements Comparable<Employee>{
	public Employee(String firstName2, String lastName2, String mobileNumber2, String email, String address) {
		this.firstName=firstName2;
		this.lastName=lastName2;
		this.mobileNumber=mobileNumber2;
		this.emailAddress=email;
		this.address=address;
	}
	String firstName;
	String lastName;
	String mobileNumber;
	String emailAddress;
	String address;
	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		return this.firstName.compareTo(o.firstName);
	}
}

public class QuestionTwentyEightEmployee {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner obj=new Scanner(System.in);
		System.out.println("Enter the number of employees");
		int num=obj.nextInt();
		List<Employee> list=new ArrayList<Employee>();
		for(int i=0;i<num;i++){
			System.out.println("Enter the first name");
			String firstName=obj.next();
			System.out.println("Enter the last name");
			String lastName=obj.next();
			System.out.println("Enter the mobile number");
			String mobileNumber=obj.next();
			System.out.println("Enter the email");
			String email=obj.next();
			System.out.println("Enter the address");
			String address=obj.next();
			Employee employee=new Employee(firstName,lastName,mobileNumber,email,address);
			list.add(employee);
		}
		Collections.sort(list);
		System.out.format("%-15s %-15s %-15s %-30s %-15s\n","Firstname","Lastname","Mobile","Email","Address");
		for(Employee employee:list){
			System.out.format("%-15s %-15s %-15s %-30s %-15s\n",employee.firstName,employee.lastName,employee.mobileNumber,employee.emailAddress,employee.address);
		}
	}

}
