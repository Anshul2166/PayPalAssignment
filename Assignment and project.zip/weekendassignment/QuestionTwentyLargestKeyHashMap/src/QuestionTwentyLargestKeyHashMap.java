import java.util.HashMap;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		int n=obj.nextInt();
		HashMap<Integer,String> map=new HashMap<Integer,String>();
		for(int i=0;i<n;i++){
			int key=obj.nextInt();
			String value=obj.next();
			map.put(key, value);
		}
		System.out.println(UserMainCode.getMaxKeyValue(map));
	}
}

class UserMainCode{
	static String getMaxKeyValue(HashMap<Integer,String> map){
		int maxKey=Integer.MIN_VALUE;
		String value="";
		for(int key:map.keySet()){
			if(key>maxKey){
				value=map.get(key);
			}
		}
		return value;
	}
}

public class QuestionTwentyLargestKeyHashMap {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
