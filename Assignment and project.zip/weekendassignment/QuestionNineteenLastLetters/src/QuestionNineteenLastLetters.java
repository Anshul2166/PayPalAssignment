import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */
class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		String line=obj.nextLine();
		String result=UserMainCode.getLastLetter(line);
		System.out.println(result);
	}
}

class UserMainCode{
	static String getLastLetter(String str){
		String result="";
		String[] splitString=str.split(" ");
		for(String s:splitString){
			result=result+Character.toUpperCase(s.charAt(s.length()-1))+"$";
		}
		return result;
	}
}

public class QuestionNineteenLastLetters {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
