import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */
public class QuestionThirtyOneProfitLoss {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner obj=new Scanner(System.in);
		System.out.println("Enter the number of dozens of toys purchased");
		double x=obj.nextInt();
		System.out.println("Enter the rate per dozen (y)");
		double y=obj.nextInt();
		System.out.println("Enter the selling price (z)");
		double z=obj.nextInt();
		double costPriceOneToy=y/12;
		double gain=z-costPriceOneToy;
		double profit=(gain/costPriceOneToy)*100;
		System.out.println("Sam's profit percentage is "+profit);
	}

}
