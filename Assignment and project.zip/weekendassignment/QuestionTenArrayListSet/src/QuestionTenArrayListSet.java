import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		int n=obj.nextInt();
		ArrayList<Integer> list1=new ArrayList<Integer>();
		ArrayList<Integer> list2=new ArrayList<Integer>();
		for(int i=0;i<n;i++){
			int num=obj.nextInt();
			list1.add(num);
		}
		for(int i=0;i<n;i++){
			int num=obj.nextInt();
			list2.add(num);
		}
		String op=obj.next();
		ArrayList<Integer> list=UserMainCode.performSetOperations(list1, list2, op);
		for(int i=0;i<list.size();i++){
			System.out.println(list.get(i));
		}
	}
}

class UserMainCode{
	static ArrayList<Integer> performSetOperations(ArrayList<Integer> list1,ArrayList<Integer> list2,String op){
		for(int i=0;i<list1.size();i++){
			System.out.println(list1.get(i));
		}
		for(int i=0;i<list2.size();i++){
			System.out.println(list2.get(i));
		}
		Set<Integer> set1=new HashSet<Integer>(list1);
		Set<Integer> set2=new HashSet<Integer>(list2);
		if(op.equals("+")){
			set1.addAll(set2);
		}
		else if(op.equals("*")){
			set1.retainAll(set2);
		}else{
			set1.removeAll(set2);
		}
		ArrayList<Integer> list=new ArrayList<Integer>(set1);
		return list;
	}
}

public class QuestionTenArrayListSet {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
