import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class Box implements Comparable<Box>{
	double length;
	double width;
	double height;
	
	public Box(double length2, double width2, double height2) {
		// TODO Auto-generated constructor stub
		this.length=length2;
		this.width=width2;
		this.height=height2;
	}
	
	public int compareTo(Box o) {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean equals(Box box){
		double volume=length*width*height;
		double otherVolume=box.length*box.width*box.height;
		if(volume==otherVolume){
			return true;
		}
		else{
			return false;
		}
	}
}

public class QuestionThirty {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner obj=new Scanner(System.in);
		System.out.println("Enter number of boxes");
		int numOfBoxes=obj.nextInt();
		Set<Box> set=new TreeSet<Box>();
		for(int i=0;i<numOfBoxes;i++){
			System.out.println("Enter details for box"+i+1);
			System.out.println("Enter length");
			double length=obj.nextDouble();
			System.out.println("Enter width");
			double width=obj.nextDouble();
			System.out.println("Enter height");
			double height=obj.nextDouble();
			Box box=new Box(length,width,height);
			set.add(box);
		}
		for(Box box:set){
			double length=box.length;
			double width=box.width;
			double height=box.height;
			double volume=length*width*height;
			System.out.println("Length="+length+" Width="+width+" Height="+height+" Volume="+volume);
		}
	}

}
