import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author ansdubey
 *
 */

class UserMainCode{
	static boolean validatePassword(String str){
		if(str.length()<8){
			return false;
		}else if(!str.matches(".*\\d.*")){
			return false;
		}else if(!str.matches(".*[a-zA-Z]+.*")){
			return false;
		}
		Pattern p = Pattern.compile("[^A-Za-z0-9]");
	    Matcher m = p.matcher(str);
	    boolean specialCharsPresent = m.find();
	    if(specialCharsPresent){
	    	return true;
	    }
	    return false;
	}
}

class Main{
	void run(){
		Scanner scanner=new Scanner(System.in);
		String str=scanner.next();
		boolean isValid=UserMainCode.validatePassword(str);
		if(isValid){
			System.out.println("Valid");
		}else{
			System.out.println("Invalid");
		}
	}
}

public class QuestionFourteenPasswordValidation {
	public static void main(String[] args) {
		Main mainObj=new Main();
		mainObj.run();
	}
}
