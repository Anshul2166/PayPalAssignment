import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class UserMainCode{
	static long findAge(String key){
		String[] date=key.split("-");
		LocalDate birthdate = LocalDate.of(Integer.parseInt(date[2]),Integer.parseInt(date[1]), Integer.parseInt(date[0]));
		LocalDate now = LocalDate.of(2014,9,1);
		long years = ChronoUnit.YEARS.between(birthdate, now);
		return years;
	}
	static TreeMap<String,Integer> calculateRevisedSalary(HashMap<String,Integer> salaryMap,HashMap<String,String> birthDateMap){
		TreeMap<String,Integer> map=new TreeMap<String,Integer>();
		for(String empId:birthDateMap.keySet()){
			int salary=salaryMap.get(empId);
			String birthDate=birthDateMap.get(empId);
			long age=findAge(birthDate);
			int bonus=0;
			if(salary<5000){
				bonus=-100;
			}else if(age<25||age>60){
				bonus=-200;
			}
			else if(age>30&&age<61){
				bonus=(int)((salary*30)/100)+salary;
			}else if(age>=25&&age<=30){
				bonus=(int)((salary*20)/100)+salary;
			}
			map.put(empId,bonus);
		}
		return map;
	}
}

class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		int n=obj.nextInt();
		HashMap<String,String> birthDateMap=new HashMap<String,String>();
		HashMap<String,Integer> salaryMap=new HashMap<String,Integer>();
		for(int i=0;i<n;i++){
			String empId=obj.next();
			String dateOfBirth=obj.next();
			int salary=obj.nextInt();
			birthDateMap.put(empId, dateOfBirth);
			salaryMap.put(empId, salary);
		}
		TreeMap<String,Integer> map=UserMainCode.calculateRevisedSalary(salaryMap, birthDateMap);
		for(String empId:map.keySet()){
			System.out.println(empId);
			System.out.println(map.get(empId));
		}
	}
}

public class QuestionFifteenEmployeeBonus {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
