import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class UserMainCode{
	static String findOldDate(String date1,String date2){
		String[] dateSplit1=date1.split("-");
		String[] dateSplit2=date2.split("-");
		boolean isYearOneOlder=checkIfYearOneIsOlder(dateSplit1,dateSplit2);
		String ans="";
		if(isYearOneOlder){
			ans=dateSplit1[1]+"/"+dateSplit1[0]+"/"+dateSplit1[2];
		}else{
			ans=dateSplit2[1]+"/"+dateSplit2[0]+"/"+dateSplit2[2];
		}
		return ans;
	}

	private static boolean checkIfYearOneIsOlder(String[] dateSplit1, String[] dateSplit2) {
		// TODO Auto-generated method stub
		int year1=Integer.parseInt(dateSplit1[2]),year2=Integer.parseInt(dateSplit2[2]);
		int month1=Integer.parseInt(dateSplit1[1]),month2=Integer.parseInt(dateSplit2[1]);
		int day1=Integer.parseInt(dateSplit1[0]),day2=Integer.parseInt(dateSplit2[0]);
		if(year1>year2){
			return false;
		}else if(year2>year1){
			return true;
		}else if(month1>month2){
			return false;
		}else if(month2>month1){
			return true;
		}else if(day1>day2){
			return false;
		}else{
			return false;
		}
	}
}

class Main{
	void run(){
		Scanner scanner=new Scanner(System.in);
		String first=scanner.next();
		String second=scanner.next();
		System.out.println(UserMainCode.findOldDate(first,second));
	}
}

public class QuestionSixteenDateFormat {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
