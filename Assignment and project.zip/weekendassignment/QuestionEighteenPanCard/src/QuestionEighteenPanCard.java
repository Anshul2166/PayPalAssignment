import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class UserMainCode{
	static int validatePAN(String str){
		if(str.length()!=8){
			return -1;
		}
		String firstThree=str.substring(0,2);
		if(!firstThree.matches("^[a-zA-Z]*$")){
			return -1;
		}
		String nextFour=str.substring(3,6);
		if(!nextFour.matches("\\d+")){
			return -1;
		}
		if(!str.substring(7).matches("^[a-zA-Z]*$")){
			return -1;
		}
		return 1;
	}
}

class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		String str=obj.next();
		int res=UserMainCode.validatePAN(str);
		if(res==1){
			System.out.println("Valid");
		}else{
			System.out.println("Invalid");
		}
	}
}

public class QuestionEighteenPanCard {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
