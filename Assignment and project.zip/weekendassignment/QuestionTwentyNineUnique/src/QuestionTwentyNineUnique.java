import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author ansdubey
 *
 */

class Card implements Comparable<Card>{
	String symbol;
	int number;
	
	public Card(String symbol2, int num) {
		// TODO Auto-generated constructor stub
		this.symbol=symbol2;
		this.number=num;
	}

	public int compareTo(Card o) {
		// TODO Auto-generated method stub
		return this.symbol.compareTo(o.symbol);
	}
	
	public boolean equals(Card card){
		if(card.symbol.equals(this.symbol)){
			return true;
		}
		else{
			return false;
		}
	}
}

public class QuestionTwentyNineUnique {
	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner obj=new Scanner(System.in);
		int n=8;
		Set<Card> cards=new TreeSet<Card>();
		for(int i=0;i<n;i++){
			System.out.println("Enter the symbol");
			String symbol=obj.next();
			System.out.println("Enter the number");
			int num=obj.nextInt();
			Card card=new Card(symbol,num);
			cards.add(card);
		}
		for(Card card:cards){
			System.out.println(card.symbol+" "+card.number);
		}
	}
}
