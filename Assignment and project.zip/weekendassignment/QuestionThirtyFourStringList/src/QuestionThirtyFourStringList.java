import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */
public class QuestionThirtyFourStringList {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner obj=new Scanner(System.in);
		List<String> list=new ArrayList<String>();
		while(true){
			System.out.println("1.Insert");
			System.out.println("2.Search");
			System.out.println("3.Delete");
			System.out.println("4.Display");
			System.out.println("5.exit");
			int option=obj.nextInt();
			if(option==1){
				System.out.println("Enter the item to be inserted");
				String item=obj.next();
				list.add(item);
				System.out.println("Item successfully added");
			}else if(option==2){
				System.out.println("Enter the item to be searched");
				String searchItem=obj.next();
				if(list.contains(searchItem)){
					System.out.println("Item found in list");
				}else{
					System.out.println("Item not found in list");
				}
			}else if(option==3){
				System.out.println("Enter the item to be deleted");
				String deleteItem=obj.next();
				int index=list.indexOf(deleteItem);
				list.remove(index);
				System.out.println("Item removed successfully");
			}else if(option==4){
				System.out.println("The items in list are:");
				for(String s:list){
					System.out.println(s);
				}
			}else{
				break;
			}
		}
	}

}
