import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class UserMainCode{
	static int findMaxDistance(int[] arr){
		int diff=Integer.MIN_VALUE;
		int index=-1;
		for(int i=1;i<arr.length;i++){
			if(arr[i]-arr[i-1]>diff){
				diff=arr[i]-arr[i-1];
				index=i;
			}
		}
		return index;
	}
}

class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		int n=obj.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++){
			arr[i]=obj.nextInt();
		}
		int index=UserMainCode.findMaxDistance(arr);
		System.out.println(index);
	}
}

public class QuestionSeventeenMaxDifference {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}
}
