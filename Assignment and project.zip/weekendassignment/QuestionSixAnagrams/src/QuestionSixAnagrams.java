import java.util.Arrays;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		String first=obj.nextLine();
		String second=obj.nextLine();
		int res=UserMainCode.getAnagram(first, second);
		if(res==1){
			System.out.println("Anagrams");
		}else{
			System.out.println("Not anagrams");
		}
	}
}

class UserMainCode{
	static int getAnagram(String first,String second){
		// Get lenghts of both strings 
		char[] str1=first.toCharArray();
		char[] str2=second.toCharArray();
        int n1 = str1.length; 
        int n2 = str2.length; 
  
        // If length of both strings is not same, 
        // then they cannot be anagram 
        if (n1 != n2) 
            return -1; 
  
        // Sort both strings 
        Arrays.sort(str1); 
        Arrays.sort(str2); 
  
        // Compare sorted strings 
        for (int i = 0; i < n1; i++) 
            if (str1[i] != str2[i]) 
                return -1; 
  
        return 1; 
	}
}

public class QuestionSixAnagrams {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
