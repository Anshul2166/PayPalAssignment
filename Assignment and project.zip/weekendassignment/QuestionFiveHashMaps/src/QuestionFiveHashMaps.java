import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class UserMainCode{
	static int getAverageOfOdd(Map<Integer,Integer> map){
		int sum=0;
		int count=0;
		for (int key:map.keySet()){
			if(key%2!=0){
				sum+=map.get(key);
				count++;
			}
		} 
		return sum/count;
	}
}

class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		int n=obj.nextInt();
		Map<Integer,Integer> map=new HashMap<Integer,Integer>();
		for(int i=0;i<n;i++){
			int key=obj.nextInt();
			int value=obj.nextInt();
			map.put(key, value);
		}
		int avg=UserMainCode.getAverageOfOdd(map);
		System.out.println(avg);
	}
}

public class QuestionFiveHashMaps {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
