import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class Main{
	//accept two strings and call the replace method in UserMainCode
	void run(){
		Scanner scanner=new Scanner(System.in);
		System.out.println("Please enter the first string");
		String first=scanner.nextLine();
		System.out.println("Please enter the second string");
		String second=scanner.nextLine();
		String result=UserMainCode.replacePlus(first,second);
		System.out.println(result);
	}
}

class UserMainCode{
	//Method replacePlus that accept two string variables and returns modified
	static String replacePlus(String first,String second){
		Set<Character> set=new HashSet<Character>();
		for(int i=0;i<second.length();i++){
			char currentCharLower=Character.toLowerCase(second.charAt(i));
			set.add(currentCharLower);
		}
		String result="";
		for(int i=0;i<first.length();i++){
			char currentCharLower=Character.toLowerCase(first.charAt(i));
			if(set.contains(currentCharLower)){
				result+=first.charAt(i);
			}
			else{
				result=result+"+";
			}
		}
		return result;
	}
}

public class QuestionOneStringReplace {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObject=new Main();
		mainObject.run();
	}

}
