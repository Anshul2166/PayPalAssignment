import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class UserMainCode{
	static boolean isLeapYear(int year){
		boolean leap = false;
        if(year % 4 == 0)
        {
            if( year % 100 == 0)
            {
                // year is divisible by 400, hence the year is a leap year
                if ( year % 400 == 0)
                    leap = true;
                else
                    leap = false;
            }
            else
                leap = true;
        }
        else
            leap = false;
        return leap;
	}
	static int getLastDayOfMonth(String str){
		String[] dateArray=str.split("-");
		int month=Integer.parseInt(dateArray[1]);
		int year=Integer.parseInt(dateArray[2]);
		if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12 )
		{
			return 31;  	
		}
		else if ( month == 4 || month == 6 || month == 9 || month == 11 )
		{
			return 30;  	
		}  
		else
		{
			if(isLeapYear(year)){
				return 29;
			}else{
				return 28;
			}
		} 
	}
}

class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		String date=obj.next();
		System.out.println(UserMainCode.getLastDayOfMonth(date));
	}
}

public class QuestionTwentyFourStringZig {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
