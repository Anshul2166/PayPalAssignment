import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class Main{
	void run(){
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++){
			arr[i]=scanner.nextInt();
		}
		int[] nonDuplicateArray=Main.removeDuplicateElements(arr, n);
		int res=UserMainCode.addUniqueEven(nonDuplicateArray);
		if(res==-1){
			System.out.println("No even numbers");
		}else{
			System.out.println(res);
		}
	}
	public static int[] removeDuplicateElements(int arr[], int n){  
        int[] temp = new int[n];  
        int j = 0;  
        for (int i=0; i<n-1; i++){  
            if (arr[i] != arr[i+1]){  
                temp[j++] = arr[i];  
            }  
         }  
        temp[j++] = arr[n-1];     
        // Changing original array  
        for (int i=0; i<j; i++){  
            arr[i] = temp[i];  
        }
        int[] res=new int[j];
        for(int i=0;i<j;i++){
        	res[i]=arr[i];
        }
        return res;  
    }
}

class UserMainCode{
	static int addUniqueEven(int[] arr){
		//return the sum of even numbers, else -1
		int res=0;
		boolean found=false;
		for(int i=0;i<arr.length;i++){
			if(arr[i]%2==0){
				found=true;
				res+=arr[i];
			}
		}
		if(!found){
			return -1;
		}
		return res;
	}
}

public class QuestionTwoSumOfEven {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
