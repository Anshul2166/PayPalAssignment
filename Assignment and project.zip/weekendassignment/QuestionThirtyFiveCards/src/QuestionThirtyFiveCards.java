import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */
public class QuestionThirtyFiveCards {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner obj=new Scanner(System.in);
		int n=obj.nextInt();
		Map<String,List<Integer>> map=new HashMap<String,List<Integer>>();
		for(int i=0;i<n;i++){
			System.out.println("Enter for card"+(i+1));
			String symbol=obj.next();
			int num=obj.nextInt();
			if(map.containsKey(symbol)){
				List<Integer> list=map.get(symbol);
				list.add(num);
				map.put(symbol,list);
			}else{
				List<Integer> list=new ArrayList<Integer>();
				list.add(num);
				map.put(symbol,list);
			}
		}
		System.out.println("Numnber of distinct cards is"+map.size());
		System.out.println("Distinct symbols are:");
		for(String symbol:map.keySet()){
			System.out.print(symbol+" ");
		}
		System.out.println();
		for(String symbol:map.keySet()){
			List<Integer> list=map.get(symbol);
			System.out.println("Cards in "+symbol+" symbol");
			int sum=0;
			for(int i:list){
				sum+=i;
				System.out.println(symbol+" "+i);
			}
			System.out.println("Sum of cards is "+sum);
			System.out.println("Numbers of cards is "+list.size());
		}
	}

}
