import java.util.Scanner;

/**
 * @author ansdubey
 *
 */

class Product{
	private long id;
	private String productName;
	private String supplierName;
	
	Product(long id){
		
	}
	Product(long id,String productName){
		supplierName="Nivas";
		this.id=id;
		this.productName=productName;
	}
	Product(long id,String productName,String supplierName){
		this.id=id;
		this.productName=productName;
		this.supplierName=supplierName;
	}
	
	void display(){
		System.out.println("Product id is "+id);
		System.out.println("Product name is "+productName);
		System.out.println("Supplier name is "+supplierName);
	}
}

public class QuestionTwentySixConstructor {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner obj=new Scanner(System.in);
		System.out.println("Enter the product id");
		long id=obj.nextLong();
		System.out.println("Enter the product name");
		String productName=obj.next();
		System.out.println("Is the product supplied by Nivas Suppliers? Type yes or no (not case sensitive)");
		String resp=obj.next();
		Product product;
		if(resp.equalsIgnoreCase("yes")){
			product=new Product(id,productName);
		}else{
			String seller=obj.next();
			product=new Product(id,productName,seller);
		}
		product.display();
	}
}
