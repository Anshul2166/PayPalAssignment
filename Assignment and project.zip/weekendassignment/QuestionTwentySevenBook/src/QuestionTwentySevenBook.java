import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class Author implements Comparable{
	private String name;
	private String email;
	private String gender;
	
	Author(String name,String email,String gender){
		this.name=name;
		this.email=email;
		this.gender=gender;
	}
	
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
}

class Book{
	private String name;
	private List<Author> authorList;
	private double price;
	private int qtyInStock = 0;
	public String getName() {
		return name;
	}
	public double getPrice() {
		return price;
	}
	public List<Author> getAuthorList() {
		return authorList;
	}
	public int getQtyInStock() {
		return qtyInStock;
	} 
	Book(){
		
	}
	Book(String name,List<Author> authorList,double price,int qtyInStock){
		this.name=name;
		this.authorList=authorList;
		this.price=price;
		this.qtyInStock=qtyInStock;
	}
	Book(String name,List<Author> authorList,double price){
		this.name=name;
		this.authorList=authorList;
		this.price=price;
	}
	public String authorListNames(){
		String names="";
		for(Author author:this.authorList){
			names+=author.getName()+" ";
		}
		return names;
	}
	public String toString(){
		String str=this.name+" authored by "+authorListNames()+" costs "+this.price;
		str=str+(this.qtyInStock!=0?"Available":"Not available");
		return str;
	}
	
}

public class QuestionTwentySevenBook {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner obj=new Scanner(System.in);
		System.out.println("Enter the book name");
		String bookName=obj.nextLine();
		System.out.println("Enter the number of authors");
		int authorsNum=obj.nextInt();
		List<Author> authorList=new ArrayList<Author>();
		for(int i=0;i<authorsNum;i++){
			System.out.println("Enter the author's name");
			String authorName=obj.next();
			System.out.println("Enter the author's email id");
			String authorEmail=obj.next();
			System.out.println("Enter the author's gender");
			String authorGender=obj.next();
			Author author=new Author(authorName,authorEmail,authorGender);
			authorList.add(author);
		}
		System.out.println("Enter the book's price");
		int price=obj.nextInt();
		System.out.println("Is the book currently available? Type �Yes/No� (Not case sensitive)");
		String resp=obj.next();
		Book book;
		if(resp.equalsIgnoreCase("yes")){
			System.out.println("Enter the quantity available");
			int qty=obj.nextInt();
			book=new Book(bookName,authorList,price,qty);
		}else{
			book=new Book(bookName,authorList,price);
		}
		System.out.println(book.toString());
		
	}

}
