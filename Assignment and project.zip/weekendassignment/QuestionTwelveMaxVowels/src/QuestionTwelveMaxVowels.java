import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class UserMainCode{
	static String getWordWithMaximumVowels(String sentence){
		String[] words=sentence.split(" ");
		// 2. Initialise a max vowel count and current max count string variable
		int maxVowelCount = 0;
		String wordWithMostVowels = "";

		// 3. Iterate over your words array.
		for (String word : words) {
		    // 4. Count the number of vowel in the current word
		    int currentVowelCount = word.split("[aeiou]", -1).length;

		    // 5. Check if it has the most vowels
		    if (currentVowelCount > maxVowelCount) {

		        // 6. Update your max count and current most vowel variables
		        wordWithMostVowels = word;
		        maxVowelCount = currentVowelCount;
		    }
		}

		// 6. Return the word with most vowels
		return wordWithMostVowels;
	}
}

class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		String sentence=obj.nextLine();
		System.out.println(UserMainCode.getWordWithMaximumVowels(sentence));
	}
}

public class QuestionTwelveMaxVowels {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
