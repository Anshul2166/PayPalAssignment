import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */
class Main{
	void run(){
		Scanner scanner=new Scanner(System.in);
		String first=scanner.nextLine();
		String second=scanner.nextLine();
		int res=UserMainCode.countNoOfWords(first,second);
		System.out.println(res);
	}
}

class UserMainCode{
	static int countNoOfWords(String first,String second){
		int res=0;
		String[] arr=first.split(" ");
		String searchElement=second.split(" ")[1];
		for(String str:arr){
			if(str.equals(searchElement)){
				res++;
			}
		}
		return res;
	}
}

public class QuestionThreeWordCount {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
