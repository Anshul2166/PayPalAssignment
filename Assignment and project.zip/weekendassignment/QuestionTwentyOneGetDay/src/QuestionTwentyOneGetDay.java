import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class UserMainCode{
	static int findDayNum(int d,int m,int y){
		int t[] = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 }; 
	    y -= (m < 3) ? 1 : 0; 
	    return ( y + y/4 - y/100 + y/400 + t[m-1] + d) % 7; 
	}
	static String getDay(String str){
		String[] splitString=str.split("-");
		int day=Integer.parseInt(splitString[1]);
		int month=Integer.parseInt(splitString[0]);
		int year=Integer.parseInt(splitString[2]);
		int numDay=findDayNum(day,month,year);
		String[] days={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
		return days[numDay];
	}
}

class Main{
	void run(){
		Scanner scanner=new Scanner(System.in);
		String str=scanner.next();
		String day=UserMainCode.getDay(str);
		System.out.println(day);
	}
}

public class QuestionTwentyOneGetDay {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
