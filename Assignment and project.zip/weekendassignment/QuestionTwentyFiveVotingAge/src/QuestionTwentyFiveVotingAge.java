import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class UserMainCode{
	static int getAge(String key){
		String[] date=key.split("/");
		LocalDate birthdate = LocalDate.of(Integer.parseInt(date[2]),Integer.parseInt(date[1]), Integer.parseInt(date[0]));
		LocalDate now = LocalDate.of(2015,1,1);
		int years = (int)ChronoUnit.YEARS.between(birthdate, now);
		return years;
	}
}

class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		String date=obj.nextLine();
		int age=UserMainCode.getAge(date);
		if(age>18){
			System.out.println("Eligible");
		}else{
			System.out.println("Not-eligible");
		}
	}
}

public class QuestionTwentyFiveVotingAge {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
