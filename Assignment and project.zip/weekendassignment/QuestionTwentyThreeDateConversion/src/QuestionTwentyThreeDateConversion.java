import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class UserMainCode{
	static String convertDateFormat(String dateString){
		String convertedDate=dateString.replace('/','-');
		return convertedDate;
	}
}

class Main{
	void run(){
		Scanner scanner=new Scanner(System.in);
		String dateString=scanner.next();
		String convertedDate=UserMainCode.convertDateFormat(dateString);
		System.out.println(convertedDate);
	}
}

public class QuestionTwentyThreeDateConversion {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
