import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */

class UserMainCode{
	static String highestScorer(ArrayList<String> list){
		int maxMarks=0;
		String topperName="";
		for(String str:list){
			String[] data=str.split("-");
			int marks1=Integer.parseInt(data[1]);
			int marks2=Integer.parseInt(data[2]);
			int marks3=Integer.parseInt(data[3]);
			int marks=marks1+marks2+marks3;
			if(marks>maxMarks){
				topperName=data[0];
				maxMarks=marks;
			}
		}
		return topperName;
	}
}

class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		int n=obj.nextInt();
		ArrayList<String> list=new ArrayList<String>();
		for(int i=0;i<n;i++){
			list.add(obj.next());
		}
		String topperName=UserMainCode.highestScorer(list);
		System.out.println(topperName);
	}
}

public class QuestionElevenMaxScorer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}

}
