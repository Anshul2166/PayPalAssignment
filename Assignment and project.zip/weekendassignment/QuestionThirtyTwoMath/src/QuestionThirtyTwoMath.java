import java.util.Scanner;

/**
 * 
 */

/**
 * @author ansdubey
 *
 */
public class QuestionThirtyTwoMath {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner obj=new Scanner(System.in);
		System.out.println("Enter the first integer");
		int first=obj.nextInt();
		System.out.println("Enter the second integer");
		int second=obj.nextInt();
		System.out.println("Absolute value of "+first+" is "+Math.abs(first));
		System.out.println("Absolute value of "+second+" is "+Math.abs(second));
		if(Math.abs(first)==Math.abs(second)){
			System.out.println(first+"="+second);
		}else{
			System.out.println(first+"!="+second);
		}
	}

}
