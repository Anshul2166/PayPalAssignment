import java.util.Scanner;

/**
 * @author ansdubey
 *
 */

class UserMainCode{
	static String swapPairs(String str){
		String adjacentReverse="";
		int len=str.length();
		for(int i=0;i<len;i=i+2){
			adjacentReverse=adjacentReverse+str.charAt(i+1)+str.charAt(i);
		}
		return adjacentReverse;
	}
}

class Main{
	void run(){
		Scanner obj=new Scanner(System.in);
		String str=obj.nextLine();
		String adjacentReverse=UserMainCode.swapPairs(str);
		System.out.println(adjacentReverse);
	}
}

public class QuestionThirteenAdjacentSwaps {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main mainObj=new Main();
		mainObj.run();
	}
}
